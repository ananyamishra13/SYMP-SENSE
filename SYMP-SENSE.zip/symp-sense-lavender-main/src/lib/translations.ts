export type Language = 'en' | 'hi' | 'ta' | 'te' | 'bn' | 'mr';

export interface LanguageOption {
  code: Language;
  name: string;
  nativeName: string;
  flag: string;
}

export const languages: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', flag: '🇮🇳' },
];

export const translations: Record<Language, Record<string, string>> = {
  en: {
    // Landing page
    'landing.badge': 'Your privacy is our priority',
    'landing.title1': 'AI Symptom Analysis',
    'landing.title2': 'Gentle, Insightful & Caring',
    'landing.subtitle': 'Describe your symptoms and receive helpful guidance — not a medical diagnosis, but a caring first step toward better health awareness.',
    'landing.cta': 'Start Analyzing Symptoms',
    'landing.getStarted': 'Get Started',
    
    // Features
    'feature.private': 'Private & Secure',
    'feature.privateDesc': 'Your health data stays with you. No storage without consent.',
    'feature.empathetic': 'Empathetic AI',
    'feature.empatheticDesc': 'Caring, supportive responses that never alarm or judge.',
    'feature.instant': 'Instant Insights',
    'feature.instantDesc': 'Quick guidance on symptoms with follow-up questions.',
    'feature.voice': 'Voice-First',
    'feature.voiceDesc': 'Speak your symptoms naturally, perfect for all users.',
    
    // How it works
    'howItWorks.title': 'How SympSense Works',
    'howItWorks.subtitle': 'A simple, caring approach to understanding your health concerns',
    'howItWorks.step1.title': 'Share Your Symptoms',
    'howItWorks.step1.desc': 'Type or speak your symptoms naturally. Our voice-first design makes it easy for everyone.',
    'howItWorks.step2.title': 'Caring Analysis',
    'howItWorks.step2.desc': 'Our AI asks gentle follow-up questions to better understand your situation.',
    'howItWorks.step3.title': 'Get Guidance',
    'howItWorks.step3.desc': 'Receive personalized insights and recommended next steps — always empathetic, never alarming.',
    
    // Disclaimer
    'disclaimer.title': 'Important Disclaimer',
    'disclaimer.text': 'SympSense provides general health information for educational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare provider for medical concerns. In case of emergency, contact your local emergency services immediately.',
    
    // Footer
    'footer.tagline': '"Awareness is the first step toward better health."',
    'footer.copyright': '© 2024 SympSense. Not a medical diagnosis.',
    
    // Chat
    'chat.title': 'AI Health Assistant',
    'chat.newChat': 'New Chat',
    'chat.welcome': "Hello! I'm SympSense, your caring health assistant 💜\n\nTell me about the symptoms you're experiencing. You can type or use the microphone to speak. Remember, I'm here to provide guidance, not medical diagnosis.",
    'chat.placeholder': 'Type or speak your symptoms...',
    'chat.listening': 'Listening...',
    'chat.listeningDesc': 'Speak your symptoms clearly.',
    'chat.voiceNotSupported': 'Voice not supported',
    'chat.voiceNotSupportedDesc': "Your browser doesn't support voice input. Please type your symptoms.",
    'chat.newConversation': 'New conversation started',
    'chat.newConversationDesc': 'Feel free to describe your symptoms.',
    'chat.sidebarDisclaimer': 'Not a medical diagnosis. Seek professional help when needed.',
    
    // Assessment
    'assessment.summary': 'Assessment Summary',
    'assessment.possibleCauses': 'Possible Causes',
    'assessment.possibleCausesNote': 'These are general possibilities, not a diagnosis.',
    'assessment.recommendations': 'Recommended Next Steps',
    'severity.low': 'Low Concern',
    'severity.moderate': 'Moderate Concern',
    'severity.high': 'High Concern',
    
    // Emergency
    'emergency.title': 'Urgent Attention Needed',
    'emergency.message': 'Your symptoms may require urgent medical attention. Please consider seeking immediate help.',
    'emergency.call112': 'Call 112',
    'emergency.call108': 'Call 108',
    'emergency.findHospital': 'Find Nearby Hospital',
    'emergency.locationDenied': 'Location access denied',
    'emergency.locationDeniedDesc': 'Please enable location access or search for hospitals manually.',
    
    // Medication Reminder
    'reminder.title': 'Medication Reminders',
    'reminder.empty': 'No reminders yet. Add one to stay on track!',
    'reminder.medicinePlaceholder': 'Medicine name',
    'reminder.addButton': 'Add Reminder',
    'reminder.added': 'Reminder added 🌿',
    'reminder.addedDesc': "We'll remind you about {medicine} at {time}.",
    'reminder.removed': 'Reminder removed',
    'reminder.removedDesc': 'The medication reminder has been deleted.',
    
    // Language
    'language.select': 'Select Language',
  },
  
  hi: {
    'landing.badge': 'आपकी गोपनीयता हमारी प्राथमिकता है',
    'landing.title1': 'AI लक्षण विश्लेषण',
    'landing.title2': 'कोमल, अंतर्दृष्टिपूर्ण और देखभाल करने वाला',
    'landing.subtitle': 'अपने लक्षणों का वर्णन करें और सहायक मार्गदर्शन प्राप्त करें — चिकित्सा निदान नहीं, बल्कि बेहतर स्वास्थ्य जागरूकता की दिशा में एक देखभालपूर्ण पहला कदम।',
    'landing.cta': 'लक्षणों का विश्लेषण शुरू करें',
    'landing.getStarted': 'शुरू करें',
    
    'feature.private': 'निजी और सुरक्षित',
    'feature.privateDesc': 'आपका स्वास्थ्य डेटा आपके पास रहता है। सहमति के बिना कोई भंडारण नहीं।',
    'feature.empathetic': 'सहानुभूतिपूर्ण AI',
    'feature.empatheticDesc': 'देखभालपूर्ण, सहायक प्रतिक्रियाएं जो कभी डराती या जज नहीं करतीं।',
    'feature.instant': 'त्वरित जानकारी',
    'feature.instantDesc': 'अनुवर्ती प्रश्नों के साथ लक्षणों पर त्वरित मार्गदर्शन।',
    'feature.voice': 'आवाज-पहले',
    'feature.voiceDesc': 'अपने लक्षणों को स्वाभाविक रूप से बोलें, सभी उपयोगकर्ताओं के लिए उपयुक्त।',
    
    'howItWorks.title': 'SympSense कैसे काम करता है',
    'howItWorks.subtitle': 'आपकी स्वास्थ्य चिंताओं को समझने का एक सरल, देखभालपूर्ण तरीका',
    'howItWorks.step1.title': 'अपने लक्षण साझा करें',
    'howItWorks.step1.desc': 'अपने लक्षणों को टाइप करें या बोलें। हमारा वॉइस-फर्स्ट डिज़ाइन सभी के लिए आसान बनाता है।',
    'howItWorks.step2.title': 'देखभालपूर्ण विश्लेषण',
    'howItWorks.step2.desc': 'हमारा AI आपकी स्थिति को बेहतर समझने के लिए सौम्य अनुवर्ती प्रश्न पूछता है।',
    'howItWorks.step3.title': 'मार्गदर्शन प्राप्त करें',
    'howItWorks.step3.desc': 'व्यक्तिगत जानकारी और अनुशंसित अगले कदम प्राप्त करें — हमेशा सहानुभूतिपूर्ण, कभी डरावना नहीं।',
    
    'disclaimer.title': 'महत्वपूर्ण अस्वीकरण',
    'disclaimer.text': 'SympSense केवल शैक्षिक उद्देश्यों के लिए सामान्य स्वास्थ्य जानकारी प्रदान करता है। यह पेशेवर चिकित्सा सलाह, निदान या उपचार का विकल्प नहीं है। चिकित्सा संबंधी चिंताओं के लिए हमेशा योग्य स्वास्थ्य सेवा प्रदाता से परामर्श करें।',
    
    'footer.tagline': '"जागरूकता बेहतर स्वास्थ्य की दिशा में पहला कदम है।"',
    'footer.copyright': '© 2024 SympSense. चिकित्सा निदान नहीं।',
    
    'chat.title': 'AI स्वास्थ्य सहायक',
    'chat.newChat': 'नई चैट',
    'chat.welcome': "नमस्ते! मैं SympSense हूं, आपका देखभालपूर्ण स्वास्थ्य सहायक 💜\n\nमुझे बताएं कि आप किन लक्षणों का अनुभव कर रहे हैं। आप टाइप कर सकते हैं या माइक्रोफोन का उपयोग करके बोल सकते हैं। याद रखें, मैं मार्गदर्शन प्रदान करने के लिए यहां हूं, चिकित्सा निदान नहीं।",
    'chat.placeholder': 'अपने लक्षण टाइप करें या बोलें...',
    'chat.listening': 'सुन रहा हूं...',
    'chat.listeningDesc': 'अपने लक्षण स्पष्ट रूप से बोलें।',
    'chat.voiceNotSupported': 'आवाज समर्थित नहीं',
    'chat.voiceNotSupportedDesc': 'आपका ब्राउज़र आवाज इनपुट का समर्थन नहीं करता। कृपया अपने लक्षण टाइप करें।',
    'chat.newConversation': 'नई बातचीत शुरू हुई',
    'chat.newConversationDesc': 'अपने लक्षणों का वर्णन करें।',
    'chat.sidebarDisclaimer': 'चिकित्सा निदान नहीं। जरूरत पड़ने पर पेशेवर मदद लें।',
    
    'assessment.summary': 'मूल्यांकन सारांश',
    'assessment.possibleCauses': 'संभावित कारण',
    'assessment.possibleCausesNote': 'ये सामान्य संभावनाएं हैं, निदान नहीं।',
    'assessment.recommendations': 'अनुशंसित अगले कदम',
    'severity.low': 'कम चिंता',
    'severity.moderate': 'मध्यम चिंता',
    'severity.high': 'उच्च चिंता',
    
    'emergency.title': 'तत्काल ध्यान देने की आवश्यकता',
    'emergency.message': 'आपके लक्षणों को तत्काल चिकित्सा ध्यान की आवश्यकता हो सकती है। कृपया तुरंत मदद लेने पर विचार करें।',
    'emergency.call112': '112 पर कॉल करें',
    'emergency.call108': '108 पर कॉल करें',
    'emergency.findHospital': 'नजदीकी अस्पताल खोजें',
    'emergency.locationDenied': 'स्थान पहुंच अस्वीकृत',
    'emergency.locationDeniedDesc': 'कृपया स्थान पहुंच सक्षम करें या मैन्युअल रूप से अस्पतालों की खोज करें।',
    
    'reminder.title': 'दवा अनुस्मारक',
    'reminder.empty': 'अभी तक कोई अनुस्मारक नहीं। ट्रैक पर रहने के लिए एक जोड़ें!',
    'reminder.medicinePlaceholder': 'दवा का नाम',
    'reminder.addButton': 'अनुस्मारक जोड़ें',
    'reminder.added': 'अनुस्मारक जोड़ा गया 🌿',
    'reminder.addedDesc': 'हम आपको {time} पर {medicine} के बारे में याद दिलाएंगे।',
    'reminder.removed': 'अनुस्मारक हटाया गया',
    'reminder.removedDesc': 'दवा अनुस्मारक हटा दिया गया है।',
    
    'language.select': 'भाषा चुनें',
  },
  
  ta: {
    'landing.badge': 'உங்கள் தனியுரிமை எங்கள் முன்னுரிமை',
    'landing.title1': 'AI அறிகுறி பகுப்பாய்வு',
    'landing.title2': 'மென்மையான, நுண்ணறிவுள்ள மற்றும் அக்கறையான',
    'landing.subtitle': 'உங்கள் அறிகுறிகளை விவரிக்கவும், உதவிகரமான வழிகாட்டுதலைப் பெறவும் — மருத்துவ நோயறிதல் அல்ல, ஆனால் சிறந்த சுகாதார விழிப்புணர்வை நோக்கிய அக்கறையான முதல் படி.',
    'landing.cta': 'அறிகுறிகளை பகுப்பாய்வு செய்யத் தொடங்குங்கள்',
    'landing.getStarted': 'தொடங்குங்கள்',
    
    'feature.private': 'தனிப்பட்ட மற்றும் பாதுகாப்பான',
    'feature.privateDesc': 'உங்கள் சுகாதார தரவு உங்களுடன் இருக்கும். சம்மதமின்றி சேமிப்பு இல்லை.',
    'feature.empathetic': 'இரக்கமுள்ள AI',
    'feature.empatheticDesc': 'பயமுறுத்தாத அல்லது தீர்ப்பளிக்காத அக்கறையான, ஆதரவான பதில்கள்.',
    'feature.instant': 'உடனடி நுண்ணறிவுகள்',
    'feature.instantDesc': 'பின்தொடர் கேள்விகளுடன் அறிகுறிகள் பற்றிய விரைவான வழிகாட்டுதல்.',
    'feature.voice': 'குரல்-முதல்',
    'feature.voiceDesc': 'உங்கள் அறிகுறிகளை இயற்கையாக பேசுங்கள், எல்லா பயனர்களுக்கும் ஏற்றது.',
    
    'chat.title': 'AI சுகாதார உதவியாளர்',
    'chat.newChat': 'புதிய அரட்டை',
    'chat.welcome': "வணக்கம்! நான் SympSense, உங்கள் அக்கறையான சுகாதார உதவியாளர் 💜\n\nநீங்கள் அனுபவிக்கும் அறிகுறிகளைப் பற்றி சொல்லுங்கள். நீங்கள் தட்டச்சு செய்யலாம் அல்லது பேச மைக்ரோஃபோனைப் பயன்படுத்தலாம்.",
    'chat.placeholder': 'உங்கள் அறிகுறிகளை தட்டச்சு செய்யவும் அல்லது பேசவும்...',
    
    'assessment.summary': 'மதிப்பீட்டு சுருக்கம்',
    'assessment.possibleCauses': 'சாத்தியமான காரணங்கள்',
    'assessment.recommendations': 'பரிந்துரைக்கப்பட்ட அடுத்த படிகள்',
    'severity.low': 'குறைந்த கவலை',
    'severity.moderate': 'மிதமான கவலை',
    'severity.high': 'அதிக கவலை',
    
    'emergency.title': 'அவசர கவனம் தேவை',
    'emergency.findHospital': 'அருகிலுள்ள மருத்துவமனையைக் கண்டறியவும்',
    
    'reminder.title': 'மருந்து நினைவூட்டல்கள்',
    'language.select': 'மொழியைத் தேர்ந்தெடுக்கவும்',
  },
  
  te: {
    'landing.badge': 'మీ గోప్యత మా ప్రాధాన్యత',
    'landing.title1': 'AI లక్షణ విశ్లేషణ',
    'landing.title2': 'మృదువైన, అంతర్దృష్టిగల మరియు శ్రద్ధగల',
    'landing.subtitle': 'మీ లక్షణాలను వివరించండి మరియు సహాయకరమైన మార్గదర్శకత్వం పొందండి — వైద్య రోగనిర్ధారణ కాదు, కానీ మెరుగైన ఆరోగ్య అవగాహన దిశగా శ్రద్ధగల మొదటి అడుగు.',
    'landing.cta': 'లక్షణాల విశ్లేషణ ప్రారంభించండి',
    'landing.getStarted': 'ప్రారంభించండి',
    
    'chat.title': 'AI ఆరోగ్య సహాయకుడు',
    'chat.newChat': 'కొత్త చాట్',
    'chat.welcome': "నమస్కారం! నేను SympSense, మీ శ్రద్ధగల ఆరోగ్య సహాయకుడు 💜\n\nమీరు అనుభవిస్తున్న లక్షణాల గురించి చెప్పండి. మీరు టైప్ చేయవచ్చు లేదా మాట్లాడటానికి మైక్రోఫోన్ ఉపయోగించవచ్చు.",
    'chat.placeholder': 'మీ లక్షణాలను టైప్ చేయండి లేదా మాట్లాడండి...',
    
    'assessment.summary': 'అంచనా సారాంశం',
    'severity.low': 'తక్కువ ఆందోళన',
    'severity.moderate': 'మధ్యస్థ ఆందోళన',
    'severity.high': 'అధిక ఆందోళన',
    
    'emergency.title': 'అత్యవసర శ్రద్ధ అవసరం',
    'language.select': 'భాషను ఎంచుకోండి',
  },
  
  bn: {
    'landing.badge': 'আপনার গোপনীয়তা আমাদের অগ্রাধিকার',
    'landing.title1': 'AI উপসর্গ বিশ্লেষণ',
    'landing.title2': 'মৃদু, অন্তর্দৃষ্টিপূর্ণ এবং যত্নশীল',
    'landing.subtitle': 'আপনার উপসর্গ বর্ণনা করুন এবং সহায়ক নির্দেশনা পান — চিকিৎসা রোগনির্ণয় নয়, বরং উন্নত স্বাস্থ্য সচেতনতার দিকে যত্নশীল প্রথম পদক্ষেপ।',
    'landing.cta': 'উপসর্গ বিশ্লেষণ শুরু করুন',
    'landing.getStarted': 'শুরু করুন',
    
    'chat.title': 'AI স্বাস্থ্য সহকারী',
    'chat.newChat': 'নতুন চ্যাট',
    'chat.welcome': "হ্যালো! আমি SympSense, আপনার যত্নশীল স্বাস্থ্য সহকারী 💜\n\nআপনি যে উপসর্গগুলি অনুভব করছেন সে সম্পর্কে বলুন। আপনি টাইপ করতে পারেন বা কথা বলতে মাইক্রোফোন ব্যবহার করতে পারেন।",
    'chat.placeholder': 'আপনার উপসর্গ টাইপ করুন বা বলুন...',
    
    'assessment.summary': 'মূল্যায়ন সারাংশ',
    'severity.low': 'কম উদ্বেগ',
    'severity.moderate': 'মাঝারি উদ্বেগ',
    'severity.high': 'উচ্চ উদ্বেগ',
    
    'emergency.title': 'জরুরি মনোযোগ প্রয়োজন',
    'language.select': 'ভাষা নির্বাচন করুন',
  },
  
  mr: {
    'landing.badge': 'तुमची गोपनीयता आमची प्राथमिकता आहे',
    'landing.title1': 'AI लक्षण विश्लेषण',
    'landing.title2': 'सौम्य, अंतर्दृष्टीपूर्ण आणि काळजी घेणारे',
    'landing.subtitle': 'तुमच्या लक्षणांचे वर्णन करा आणि उपयुक्त मार्गदर्शन मिळवा — वैद्यकीय निदान नाही, परंतु चांगल्या आरोग्य जागरूकतेच्या दिशेने काळजी घेणारी पहिली पायरी.',
    'landing.cta': 'लक्षणांचे विश्लेषण सुरू करा',
    'landing.getStarted': 'सुरू करा',
    
    'chat.title': 'AI आरोग्य सहाय्यक',
    'chat.newChat': 'नवीन चॅट',
    'chat.welcome': "नमस्कार! मी SympSense आहे, तुमचा काळजी घेणारा आरोग्य सहाय्यक 💜\n\nतुम्हाला जाणवत असलेल्या लक्षणांबद्दल सांगा. तुम्ही टाइप करू शकता किंवा बोलण्यासाठी माइक्रोफोन वापरू शकता.",
    'chat.placeholder': 'तुमची लक्षणे टाइप करा किंवा बोला...',
    
    'assessment.summary': 'मूल्यांकन सारांश',
    'severity.low': 'कमी चिंता',
    'severity.moderate': 'मध्यम चिंता',
    'severity.high': 'उच्च चिंता',
    
    'emergency.title': 'तात्काळ लक्ष देणे आवश्यक',
    'language.select': 'भाषा निवडा',
  },
};

export function getTranslation(language: Language, key: string): string {
  return translations[language]?.[key] || translations['en'][key] || key;
}
