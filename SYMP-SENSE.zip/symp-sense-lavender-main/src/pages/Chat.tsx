import { useState, useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { ChatInput } from "@/components/ChatInput";
import { ChatMessage } from "@/components/ChatMessage";
import { AssessmentCard } from "@/components/AssessmentCard";
import { EmergencyAlert } from "@/components/EmergencyAlert";
import { MedicationReminder } from "@/components/MedicationReminder";
import { LanguageSelector } from "@/components/LanguageSelector";
import { Button } from "@/components/ui/button";
import { Plus, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  assessment?: {
    summary: string;
    severity: "low" | "moderate" | "high";
    possibleCauses: string[];
    recommendations: string[];
  };
  isEmergency?: boolean;
}

export default function Chat() {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Initialize welcome message when language changes
  useEffect(() => {
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content: t('chat.welcome'),
      },
    ]);
  }, [language]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const parseAIResponse = (content: string): Partial<Message> => {
    try {
      // Try to extract JSON from the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        
        if (parsed.type === 'emergency') {
          return {
            content: parsed.message,
            isEmergency: true,
          };
        }
        
        if (parsed.type === 'assessment') {
          return {
            content: parsed.summary,
            assessment: {
              summary: parsed.summary,
              severity: parsed.severity || 'low',
              possibleCauses: parsed.possibleCauses || [],
              recommendations: parsed.recommendations || [],
            },
          };
        }
        
        if (parsed.type === 'followup') {
          return {
            content: parsed.message,
          };
        }
      }
    } catch {
      // If JSON parsing fails, return the content as-is
    }
    
    return { content };
  };

  const handleSend = useCallback(async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const conversationHistory = messages
        .filter((m) => m.id !== "welcome")
        .map((m) => ({ role: m.role, content: m.content }));

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/symptom-analysis`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            messages: [...conversationHistory, { role: "user", content }],
            language,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 429) {
          toast({
            title: "Please wait",
            description: "Too many requests. Please try again in a moment.",
            variant: "destructive",
          });
        } else if (response.status === 402) {
          toast({
            title: "Service unavailable",
            description: "Please try again later.",
            variant: "destructive",
          });
        }
        throw new Error(errorData.error || "Failed to get response");
      }

      // Handle streaming response
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullContent = "";
      let assistantMessageId = (Date.now() + 1).toString();

      // Add placeholder assistant message
      setMessages((prev) => [
        ...prev,
        { id: assistantMessageId, role: "assistant", content: "" },
      ]);

      if (reader) {
        let buffer = "";
        
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          
          // Process complete lines
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6).trim();
              if (data === "[DONE]") continue;

              try {
                const parsed = JSON.parse(data);
                const deltaContent = parsed.choices?.[0]?.delta?.content;
                if (deltaContent) {
                  fullContent += deltaContent;
                  setMessages((prev) =>
                    prev.map((m) =>
                      m.id === assistantMessageId
                        ? { ...m, content: fullContent }
                        : m
                    )
                  );
                }
              } catch {
                // Skip malformed JSON
              }
            }
          }
        }
      }

      // Parse final response for structured data
      const parsedResponse = parseAIResponse(fullContent);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMessageId
            ? { ...m, ...parsedResponse, content: parsedResponse.content || fullContent }
            : m
        )
      );

    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Something went wrong",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [messages, language, toast]);

  const handleNewChat = () => {
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content: t('chat.welcome'),
      },
    ]);
    toast({
      title: t('chat.newConversation'),
      description: t('chat.newConversationDesc'),
    });
  };

  const handleFindHospital = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          window.open(
            `https://www.google.com/maps/search/hospital/@${latitude},${longitude},14z`,
            "_blank"
          );
        },
        () => {
          toast({
            title: t('emergency.locationDenied'),
            description: t('emergency.locationDeniedDesc'),
            variant: "destructive",
          });
        }
      );
    } else {
      window.open("https://www.google.com/maps/search/hospital", "_blank");
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-80 flex-col border-r border-border/50 bg-card/50 p-4">
        <div className="flex items-center justify-between mb-6">
          <Logo />
          <Button variant="soft" size="icon-sm" onClick={handleNewChat}>
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-auto">
          <MedicationReminder />
        </div>

        <p className="text-xs text-muted-foreground text-center mt-4">
          {t('chat.sidebarDisclaimer')}
        </p>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col max-h-screen">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border/50 bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() => navigate("/")}
              className="lg:hidden"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <Logo className="lg:hidden" />
            <span className="hidden lg:block text-lg font-semibold">
              {t('chat.title')}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <LanguageSelector />
            <Button variant="soft" size="sm" onClick={handleNewChat}>
              <Plus className="w-4 h-4 mr-1" />
              {t('chat.newChat')}
            </Button>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="space-y-4">
              <ChatMessage role={message.role} content={message.content} />
              {message.isEmergency && (
                <EmergencyAlert onFindHospital={handleFindHospital} />
              )}
              {message.assessment && (
                <AssessmentCard {...message.assessment} />
              )}
            </div>
          ))}
          {isLoading && (
            <ChatMessage role="assistant" content="" isTyping />
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border/50 bg-card/30 backdrop-blur-sm">
          <div className="max-w-3xl mx-auto">
            <ChatInput 
              onSend={handleSend} 
              disabled={isLoading}
              placeholder={t('chat.placeholder')}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
