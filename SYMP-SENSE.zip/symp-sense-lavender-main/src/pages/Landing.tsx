import { Link } from "react-router-dom";
import { ArrowRight, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { FeatureCards } from "@/components/FeatureCards";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useLanguage } from "@/contexts/LanguageContext";
import heroBg from "@/assets/hero-bg.png";

export default function Landing() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      {/* Decorative Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <img 
          src={heroBg} 
          alt="" 
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-background" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-6 max-w-7xl mx-auto">
        <Logo />
        <div className="flex items-center gap-3">
          <LanguageSelector />
          <Link to="/chat">
            <Button variant="soft">{t('landing.getStarted')}</Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-6">
        <section className="py-20 md:py-32 text-center">
          <div className="animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-lavender-light text-lavender-dark text-sm font-medium mb-8">
              <Shield className="w-4 h-4" />
              {t('landing.badge')}
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              <span className="gradient-primary bg-clip-text text-transparent">
                {t('landing.title1')}
              </span>
              <br />
              <span className="text-foreground/90">
                {t('landing.title2')}
              </span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              {t('landing.subtitle')}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/chat">
                <Button variant="hero" size="lg" className="min-w-[200px]">
                  {t('landing.cta')}
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Feature Cards */}
        <section className="py-16">
          <FeatureCards />
        </section>

        {/* How It Works */}
        <section className="py-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t('howItWorks.title')}
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              {t('howItWorks.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                titleKey: "howItWorks.step1.title",
                descKey: "howItWorks.step1.desc",
              },
              {
                step: "2",
                titleKey: "howItWorks.step2.title",
                descKey: "howItWorks.step2.desc",
              },
              {
                step: "3",
                titleKey: "howItWorks.step3.title",
                descKey: "howItWorks.step3.desc",
              },
            ].map((item, index) => (
              <div
                key={item.step}
                className="text-center p-6 animate-slide-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center text-2xl font-bold text-primary-foreground mx-auto mb-4 shadow-glow">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{t(item.titleKey)}</h3>
                <p className="text-muted-foreground">{t(item.descKey)}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Disclaimer */}
        <section className="py-16 text-center">
          <div className="glass-card max-w-3xl mx-auto p-8 rounded-3xl">
            <Shield className="w-10 h-10 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">{t('disclaimer.title')}</h3>
            <p className="text-muted-foreground leading-relaxed">
              {t('disclaimer.text')}
            </p>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 py-8 mt-20">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <Logo />
          <p className="text-sm text-muted-foreground">
            {t('footer.tagline')}
          </p>
          <p className="text-sm text-muted-foreground">
            {t('footer.copyright')}
          </p>
        </div>
      </footer>
    </div>
  );
}
