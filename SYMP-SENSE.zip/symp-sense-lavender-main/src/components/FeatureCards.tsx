import { Shield, Sparkles, Zap, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";

export function FeatureCards() {
  const { t } = useLanguage();

  const features = [
    {
      icon: Shield,
      titleKey: "feature.private",
      descKey: "feature.privateDesc",
    },
    {
      icon: Heart,
      titleKey: "feature.empathetic",
      descKey: "feature.empatheticDesc",
    },
    {
      icon: Zap,
      titleKey: "feature.instant",
      descKey: "feature.instantDesc",
    },
    {
      icon: Sparkles,
      titleKey: "feature.voice",
      descKey: "feature.voiceDesc",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {features.map((feature, index) => (
        <Card
          key={feature.titleKey}
          variant="feature"
          className="animate-slide-up"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <CardContent className="p-6 text-center">
            <div className="mx-auto mb-4 w-14 h-14 rounded-2xl bg-lavender-light flex items-center justify-center">
              <feature.icon className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-semibold text-lg mb-2">{t(feature.titleKey)}</h3>
            <p className="text-muted-foreground text-sm">{t(feature.descKey)}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
