import { AlertTriangle, Phone, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

interface EmergencyAlertProps {
  onFindHospital: () => void;
}

export function EmergencyAlert({ onFindHospital }: EmergencyAlertProps) {
  const { t } = useLanguage();

  return (
    <Card className="border-emergency/50 bg-emergency/5 animate-scale-in">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-emergency">
          <AlertTriangle className="w-5 h-5" />
          {t('emergency.title')}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-foreground">
          {t('emergency.message')}
        </p>
        
        <div className="flex flex-wrap gap-3">
          <a href="tel:112" className="flex-1 min-w-[140px]">
            <Button variant="emergency" className="w-full gap-2">
              <Phone className="w-4 h-4" />
              {t('emergency.call112')}
            </Button>
          </a>
          <a href="tel:108" className="flex-1 min-w-[140px]">
            <Button variant="emergency" className="w-full gap-2">
              <Phone className="w-4 h-4" />
              {t('emergency.call108')}
            </Button>
          </a>
        </div>
        
        <Button 
          variant="outline" 
          className="w-full gap-2 border-emergency/30 text-emergency hover:bg-emergency/10"
          onClick={onFindHospital}
        >
          <MapPin className="w-4 h-4" />
          {t('emergency.findHospital')}
        </Button>
      </CardContent>
    </Card>
  );
}
