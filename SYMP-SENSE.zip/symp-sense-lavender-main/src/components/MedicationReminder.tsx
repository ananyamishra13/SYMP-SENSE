import { useState } from "react";
import { Plus, Clock, Trash2, Bell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface Reminder {
  id: string;
  medicine: string;
  time: string;
}

export function MedicationReminder() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [medicine, setMedicine] = useState("");
  const [time, setTime] = useState("");
  const { toast } = useToast();
  const { t } = useLanguage();

  const addReminder = () => {
    if (medicine && time) {
      const newReminder: Reminder = {
        id: Date.now().toString(),
        medicine,
        time,
      };
      setReminders([...reminders, newReminder]);
      setMedicine("");
      setTime("");
      setShowForm(false);
      toast({
        title: t('reminder.added'),
        description: t('reminder.addedDesc').replace('{medicine}', medicine).replace('{time}', time),
      });
    }
  };

  const removeReminder = (id: string) => {
    setReminders(reminders.filter((r) => r.id !== id));
    toast({
      title: t('reminder.removed'),
      description: t('reminder.removedDesc'),
    });
  };

  return (
    <Card variant="glass" className="animate-fade-in">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            {t('reminder.title')}
          </div>
          <Button
            variant="soft"
            size="sm"
            onClick={() => setShowForm(!showForm)}
          >
            <Plus className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {showForm && (
          <div className="space-y-3 p-3 bg-muted/50 rounded-xl animate-scale-in">
            <Input
              placeholder={t('reminder.medicinePlaceholder')}
              value={medicine}
              onChange={(e) => setMedicine(e.target.value)}
              className="bg-card"
            />
            <Input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="bg-card"
            />
            <Button onClick={addReminder} className="w-full">
              {t('reminder.addButton')}
            </Button>
          </div>
        )}

        {reminders.length === 0 && !showForm ? (
          <p className="text-muted-foreground text-sm text-center py-4">
            {t('reminder.empty')}
          </p>
        ) : (
          <div className="space-y-2">
            {reminders.map((reminder) => (
              <div
                key={reminder.id}
                className="flex items-center justify-between p-3 bg-muted/30 rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-lavender-light flex items-center justify-center">
                    <Clock className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{reminder.medicine}</p>
                    <p className="text-sm text-muted-foreground">{reminder.time}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={() => removeReminder(reminder.id)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
