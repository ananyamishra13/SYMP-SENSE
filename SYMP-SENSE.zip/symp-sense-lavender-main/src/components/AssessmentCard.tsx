import { Brain, Lightbulb, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";

type Severity = "low" | "moderate" | "high";

interface AssessmentCardProps {
  summary: string;
  severity: Severity;
  possibleCauses: string[];
  recommendations: string[];
}

const severityColors: Record<Severity, string> = {
  low: "bg-success/20 text-success border-success/30",
  moderate: "bg-warning/20 text-warning border-warning/30",
  high: "bg-emergency/20 text-emergency border-emergency/30",
};

export function AssessmentCard({ summary, severity, possibleCauses, recommendations }: AssessmentCardProps) {
  const { t } = useLanguage();

  const severityLabels: Record<Severity, string> = {
    low: t('severity.low'),
    moderate: t('severity.moderate'),
    high: t('severity.high'),
  };

  return (
    <div className="space-y-4 animate-slide-up">
      {/* Summary Card */}
      <Card variant="elevated" className="border-l-4 border-l-primary">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center justify-between text-lg">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              {t('assessment.summary')}
            </div>
            <Badge className={`${severityColors[severity]} font-medium`}>
              {severityLabels[severity]}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-foreground leading-relaxed">{summary}</p>
        </CardContent>
      </Card>

      {/* Possible Causes */}
      {possibleCauses.length > 0 && (
        <Card variant="glass">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lightbulb className="w-5 h-5 text-coral" />
              {t('assessment.possibleCauses')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              {t('assessment.possibleCausesNote')}
            </p>
            <div className="flex flex-wrap gap-2">
              {possibleCauses.map((cause) => (
                <Badge
                  key={cause}
                  variant="secondary"
                  className="bg-lavender-light text-lavender-dark border-0 px-3 py-1"
                >
                  {cause}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <Card variant="glass">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <ArrowRight className="w-5 h-5 text-success" />
              {t('assessment.recommendations')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {recommendations.map((rec, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="w-6 h-6 rounded-full bg-success/20 text-success flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <span className="text-foreground">{rec}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
